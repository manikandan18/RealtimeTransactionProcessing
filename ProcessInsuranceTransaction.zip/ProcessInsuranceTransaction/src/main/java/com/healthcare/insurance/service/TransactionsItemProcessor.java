package com.healthcare.insurance.service;

import java.util.HashMap;

import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.healthcare.insurance.dao.PlanCoverageDao;
import com.healthcare.insurance.dao.PlanDescriptionsDao;
import com.healthcare.insurance.dao.PolicyDao;
import com.healthcare.insurance.dao.TransactionsProcessedDao;
import com.healthcare.insurance.model.PlanCoverage;
import com.healthcare.insurance.model.PlanDescriptions;
import com.healthcare.insurance.model.Policy;
import com.healthcare.insurance.model.TransactionsProcessed;
//@ComponentScan
@Component
@Transactional
@Configuration
@Service
public class TransactionsItemProcessor implements 
               ItemProcessor<TransactionsProcessed, TransactionsProcessed>{
    @Autowired
    private PlanDescriptionsDao planDescriptionsDao;
    @Autowired
    private PolicyDao policyDao;
    @Autowired
    private PlanCoverageDao planCoverageDao;
    @Autowired
    private TransactionsProcessedDao transactionsProcessedDao;  
    HashMap<String, AccumulationForYear> hm = new HashMap<String, AccumulationForYear>();
	public TransactionsProcessed process(TransactionsProcessed tp) throws Exception {
		// TODO Auto-generated method stub
		//Get individual and family amounts from policy descriptions table using dao
		//Compare it with the individual accumulated and family accumulated in
		//policy table for the planid in csv file. Use Dao for this as well.
		//If greater, then get the percentage from plan coverage table and apply as it
		//is to calculate the charges and write it with comma separated string into
		//an output file. Write to transactions_processed table in parallel.
		
		String preventiveCare = "Preventive Care";
		final String policyNotFoundErrorCode = "E0001";
		final String policyNotFoundErrorMessage = "Policy holder does not exist";
		/* Check for Policy Id and Policy Holder id combination of input
		 * transaction with data in Policy table.
		 */
		System.out.println("Policy Id is "+tp.getPolicyId());
		System.out.println("Policy holder Id is "+tp.getPolicyHolderId());
		if (policyDao == null)
			System.out.println("Policy Dao is null");
		Policy policy = policyDao.getPolicyByPolicyId(tp.getPolicyId(), 
				                                      tp.getPolicyHolderId());
		if (policy == null) {
			/* TODO There is no policy. So, set error */
			tp.setErrorCode(policyNotFoundErrorCode);
			tp.setErrorMessage(policyNotFoundErrorMessage);
            tp.setCoverageDescription("");
            tp.setProcessingMessage("");
         
	        transactionsProcessedDao.insert(tp);
	        return tp;
		}
		/* Use policy id to get plan id from policy dao */
		PlanDescriptions planDescriptions = planDescriptionsDao.
				      getPlanDescriptionsForPlanId(policy.getPlanId());

        /* TODO business logic for individual and family accumulation */
		Double individualAccumulationAsPerPolicy = planDescriptions.getAnnualDeductibleIndividual();
		Double familyAccumulationAsPerPolicy = 0.00;
		Double individualAccumulationForYear = 0.00;
		Double familyAccumulationForYear = 0.00;
		Double planPays = 0.00;
		Double policyHolderPays = 0.00;
		Double billedAmount = tp.getBilledAmount();
		String coverageType = planDescriptions.getCoverageType().trim();
		final String familyCoverageType = "Family";
		StringBuilder policyIdAndPolicyHolderIdCombo = new StringBuilder();
		policyIdAndPolicyHolderIdCombo.append(policy.getPolicyId());
		policyIdAndPolicyHolderIdCombo.append("-");
		policyIdAndPolicyHolderIdCombo.append(policy.getPolicyHolderId());
		String hmId = policyIdAndPolicyHolderIdCombo.toString();
		if (!hm.containsKey(hmId)) {
			//Add the family and individual accumulation from policy
			
			hm.put(hmId, new AccumulationForYear(policy.getIndividualAccumulated(),
					policy.getFamilyAccumulated()));
			individualAccumulationForYear = policy.getIndividualAccumulated();
			if (coverageType.equals(familyCoverageType)) {
				familyAccumulationForYear = policy.getFamilyAccumulated();
			}
		}
		else {
			//The combination already exists. Use it.
			AccumulationForYear acc = hm.get(hmId);
			individualAccumulationForYear = acc.getIndividualAccumulationForYear();
			familyAccumulationForYear = acc.getFamilyAccumulationForYear();
		}
		System.out.println("Value of policy is "+policy.getIndividualAccumulated());
		if (coverageType.equals(familyCoverageType)) {
			familyAccumulationAsPerPolicy = planDescriptions.getAnnualDeductibleFamily();
			//familyAccumulationForYear = policy.getFamilyAccumulated();
		}
		if (tp.getMainCategory().trim().equals(preventiveCare)) {
			//TODO just add it in table and output transactions as billed amount
			//will be 0.00 for Preventive Care. Return as no further validations 
			//required.
		}
		PlanCoverage planCovered = planCoverageDao.getPlanCoverage(
			    policy.getPolicyId(), policy.getPolicyHolderId(), policy.getPlanId(),
			    tp.getMainCategory().trim(), tp.getSubCategory().trim());

		if (coverageType.equals(familyCoverageType)) {
 
			if ((familyAccumulationForYear > familyAccumulationAsPerPolicy)
					|| (individualAccumulationForYear > individualAccumulationAsPerPolicy)) {
			/* 
			 * Apply the transaction charges with percentage or amount 
			 * configured in plan coverage. The individual or family 
			 * doesn't matter in this case as the family/individual accumulation
			 * has already exceeded
			 * 
			 */
				if (planCovered.getIsPercentage().trim().equals("No")) {
					planPays = Math.min(billedAmount, planCovered.getCoverageAmount());
    			}
				else {
				    planPays = (billedAmount * planCovered.getCoverageAmount())/100;
				    
				}
				policyHolderPays = billedAmount - planPays;
				individualAccumulationForYear += policyHolderPays;
				familyAccumulationForYear += policyHolderPays;
				hm.put(hmId, new AccumulationForYear(individualAccumulationForYear, 
						familyAccumulationForYear));
				tp = persistData(planPays, policyHolderPays, planCovered,
					    policy, planDescriptions, individualAccumulationForYear, familyAccumulationForYear, tp);				
		     }
		     else {
			/*
			 * Take the maximum of individual accumulation per year or family 
			 * accumulation along with billed charges. Then apply 
			 * 
			 */  Double chargesToConsiderForPlanPayment = 0.00;
		    	 if ((billedAmount+familyAccumulationForYear > familyAccumulationAsPerPolicy) 
		    		|| (billedAmount+individualAccumulationForYear > individualAccumulationAsPerPolicy)){
		    		 /* The amount exceeds along with billed amount. So, pick the
		    		  * maximum of difference in family or individual accumulation
		    		  */

		    		 chargesToConsiderForPlanPayment = Math.max((billedAmount+familyAccumulationForYear-familyAccumulationAsPerPolicy),
		    				 (billedAmount+individualAccumulationForYear-individualAccumulationAsPerPolicy));
		    		 if (planCovered.getIsPercentage().trim().equals("No")) {
		    			 planPays = Math.min(chargesToConsiderForPlanPayment, billedAmount);
		    		 }
		    		 else
		    		     planPays = (chargesToConsiderForPlanPayment * planCovered.getCoverageAmount())/100;
		    		 policyHolderPays = billedAmount - planPays;
		    		 individualAccumulationForYear += policyHolderPays;
		    		 familyAccumulationForYear += policyHolderPays;
						hm.put(hmId, new AccumulationForYear(individualAccumulationForYear, 
								familyAccumulationForYear));
		    		 tp = persistData(planPays, policyHolderPays, planCovered,
							    policy, planDescriptions, individualAccumulationForYear, familyAccumulationForYear, tp);    		 
		    	 }
		    	 else {
		    		 /* Plan doesn't have to cover as deductible isn't met for
		    		  * family or individual
		    		  */
		    		 planPays = 0.00;
		    		 policyHolderPays = billedAmount;
		    		 individualAccumulationForYear += policyHolderPays;
		    		 familyAccumulationForYear += policyHolderPays;
		    		 System.out.println("Value of policy before persist is "+policy.getIndividualAccumulated());
						hm.put(hmId, new AccumulationForYear(individualAccumulationForYear, 
								familyAccumulationForYear));
		    		 tp = persistData(planPays, policyHolderPays, planCovered,
							    policy, planDescriptions, individualAccumulationForYear, familyAccumulationForYear, tp);    		 		    		 
		    	 }
		     }
		}
		else {
			/* The coverage type is not family. So, consider only
			 * individual charges
			 */
			if (individualAccumulationForYear > individualAccumulationAsPerPolicy) {
				if (planCovered.getIsPercentage().trim().equals("No")) {
					planPays = Math.min(billedAmount, planCovered.getCoverageAmount());
    			}
				else
				    planPays = (billedAmount * planCovered.getCoverageAmount())/100;
				policyHolderPays = billedAmount - planPays;
				individualAccumulationForYear += policyHolderPays;
				hm.put(hmId, new AccumulationForYear(individualAccumulationForYear, 
						familyAccumulationForYear));
				tp = persistData(planPays, policyHolderPays, planCovered,
					    policy, planDescriptions, individualAccumulationForYear, familyAccumulationForYear, tp);				
			}
			else if (billedAmount+individualAccumulationForYear > individualAccumulationAsPerPolicy) {
				double chargesToConsiderForPlanPayment = 0.00;
				chargesToConsiderForPlanPayment = billedAmount+individualAccumulationForYear
						-individualAccumulationAsPerPolicy;
	    		 if (planCovered.getIsPercentage().trim().equals("No")) {
	    			 planPays = Math.min(chargesToConsiderForPlanPayment, billedAmount);
	    		 }
	    		 else
	    		     planPays = (chargesToConsiderForPlanPayment * planCovered.getCoverageAmount())/100;
	    		 policyHolderPays = billedAmount - planPays;
	    		 individualAccumulationForYear += policyHolderPays;
					hm.put(hmId, new AccumulationForYear(individualAccumulationForYear, 
							familyAccumulationForYear));
	    		 tp = persistData(planPays, policyHolderPays, planCovered,
						    policy, planDescriptions, individualAccumulationForYear, familyAccumulationForYear, tp);    
			}
			else {
	    		 planPays = 0.00;
	    		 policyHolderPays = billedAmount;
	    		 individualAccumulationForYear += policyHolderPays;
					hm.put(hmId, new AccumulationForYear(individualAccumulationForYear, 
							familyAccumulationForYear));
	    		 tp = persistData(planPays, policyHolderPays, planCovered,
						    policy, planDescriptions, individualAccumulationForYear, familyAccumulationForYear, tp);    		 		    		 				
			}
		}
		if (tp.getErrorCode() == null) {
			tp.setErrorCode("");
            tp.setErrorMessage("");
		} 
		if ((tp.getCoverageDescription() == null) || tp.getCoverageDescription().isEmpty()) {
            tp.setCoverageDescription("");
            tp.setProcessingMessage("");			
		}
		return tp;
	}
	@Transactional
	private TransactionsProcessed persistData(Double planPays, Double policyHolderPays, PlanCoverage planCovered,
			Policy policy, PlanDescriptions planDescriptions,
			Double individualAccumulationForYear, Double familyAccumulationForYear,
			TransactionsProcessed tp) {
		// TODO Auto-generated method stub
		System.out.println("Individual Accumulation for Year "+individualAccumulationForYear);
		String notMet = "ANNUAL DECUCTIBLE  (INDIVIDUAL or FAMILY) not met, plan pays 0%";
        StringBuilder familyMet = new StringBuilder();
        familyMet.append("ANNUAL DECUCTIBLE  (FAMILY) met, plan pays ");
        StringBuilder individualMet = new StringBuilder();
        individualMet.append("ANNUAL DECUCTIBLE  (INDIVIDUAL) met, plan pays ");       
        String coverageAmountString = null;
		tp.setPlanPaysUSD((double) Math.round(planPays * 100) / 100.0);
		tp.setPolicyHolderPaysUSD(policyHolderPays);
		tp.setIndividualAccumulated(individualAccumulationForYear);
		tp.setFamilyAccumulated(familyAccumulationForYear);
		tp.setCoverageDescription(planCovered.getCoverageDescription());
        if ((individualAccumulationForYear <= planDescriptions.getAnnualDeductibleIndividual() 
        		&& familyAccumulationForYear <= planDescriptions.getAnnualDeductibleFamily()))
        	tp.setProcessingMessage(notMet);	
        else if ((individualAccumulationForYear < planDescriptions.getAnnualDeductibleIndividual()
        		&& (familyAccumulationForYear > planDescriptions.getAnnualDeductibleFamily()
        		|| tp.getBilledAmount()+familyAccumulationForYear > planDescriptions.getAnnualDeductibleFamily()))) {
        	coverageAmountString = String.valueOf(planCovered.getCoverageAmount());
        	familyMet.append(coverageAmountString);
        	familyMet.append("%");
        	tp.setProcessingMessage(familyMet.toString());
        }
        else if ((individualAccumulationForYear > planDescriptions.getAnnualDeductibleIndividual() 
        		  || tp.getBilledAmount()+individualAccumulationForYear > planDescriptions.getAnnualDeductibleIndividual())
        		&& familyAccumulationForYear < planDescriptions.getAnnualDeductibleFamily()) {
        	coverageAmountString = String.valueOf(planCovered.getCoverageAmount());
        	individualMet.append(coverageAmountString);
        	individualMet.append("%");
        	tp.setProcessingMessage(individualMet.toString());
        } 
        else if (tp.getBilledAmount()+individualAccumulationForYear > planDescriptions.getAnnualDeductibleIndividual()
        		 && tp.getBilledAmount()+familyAccumulationForYear > planDescriptions.getAnnualDeductibleFamily()) {
        	coverageAmountString = String.valueOf(planCovered.getCoverageAmount());
        	StringBuilder individualOrFamily = new StringBuilder();
        	individualOrFamily = tp.getBilledAmount()+familyAccumulationForYear
        			         -planDescriptions.getAnnualDeductibleFamily() > tp.getBilledAmount()+
        			         individualAccumulationForYear - planDescriptions.getAnnualDeductibleIndividual()
        			         ?familyMet.append(coverageAmountString):individualMet.append(coverageAmountString);
        	individualOrFamily.append("%");
        	tp.setProcessingMessage(individualOrFamily.toString());
        }
        //transactionsProcessedDao.insert(tp);
        /* 
         * We have to maintain Individual and family accumulation between server restarts 
         * in policy table
         */
        int noOfRowsUpdated = policyDao.updatePolicyWithAccumulationForYear(policy.getPolicyId(), policy.getPolicyHolderId(), 
        		individualAccumulationForYear, familyAccumulationForYear);
        System.out.println("The updated count is "+noOfRowsUpdated);
        return tp;
	}    
}
