package com.healthcare.insurance.model;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.NotNull;

import org.springframework.stereotype.Component;
@Component
@Entity
@Access(AccessType.PROPERTY)

public class TransactionFile {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}	
   public String getInput_name() {
		return input_name;
	}
   
	public void setInput_name(String input_name) {
		this.input_name = input_name;
	}
	public String getOutput_name() {
		return output_name;
	}
	public void setOutput_name(String output_name) {
		this.output_name = output_name;
	}
	@NotNull	
    String input_name;
	@NotNull
    String output_name;
	private long id;
}
