package com.healthcare.insurance.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.healthcare.insurance.dao.PlanCoverageDao;
import com.healthcare.insurance.model.PlanCoverage;

@Repository("planCoverageDao")
public class PlanCoverageDaoImpl implements PlanCoverageDao {
    @Autowired
    private SessionFactory sessionFactory;
    protected Session getSession(){
        return sessionFactory.openSession();
    }
    
	public PlanCoverage getPlanCoverage(long policyId, long policyHolderId, 
			                            String planId, String mainCategory,
			                            String subCategory) {
		
		// TODO Auto-generated method stub
		System.out.println("Plan id:"+planId+" Main Category:"+mainCategory+" Sub Category:"+subCategory);
		String sql = "from PlanCoverage where PLAN_ID = :id and "
					+ "MAIN_CATEGORY = :mainCat";
		Query query = getSession().createQuery(sql);
		query.setString("id", planId);
		query.setString("mainCat", mainCategory);
		//query.setString("subCat", "%"+subCategory+"%");
		List<PlanCoverage> pd = (List<PlanCoverage>) query.list();
		for (PlanCoverage pc:pd) {
			System.out.println("Sub Category:"+pc.getSubCategory());
			if (pc.getSubCategory().contains(subCategory))
				return pc;
		}
		return null;
	}
}
