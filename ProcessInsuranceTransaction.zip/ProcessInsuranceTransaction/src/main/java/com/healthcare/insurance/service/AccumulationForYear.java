package com.healthcare.insurance.service;

public class AccumulationForYear {
   public double getIndividualAccumulationForYear() {
		return individualAccumulationForYear;
	}
	public void setIndividualAccumulationForYear(double individualAccumulationForYear) {
		this.individualAccumulationForYear = individualAccumulationForYear;
	}
	public double getFamilyAccumulationForYear() {
		return familyAccumulationForYear;
	}
	public void setFamilyAccumulationForYear(double familyAccumulationForYear) {
		this.familyAccumulationForYear = familyAccumulationForYear;
	}
double individualAccumulationForYear;
   double familyAccumulationForYear;
   public AccumulationForYear(double individualAccumulationForYear, 
		   double familyAccumulationForYear) {
	   this.individualAccumulationForYear = individualAccumulationForYear;
	   this.familyAccumulationForYear = familyAccumulationForYear;
   }
}
