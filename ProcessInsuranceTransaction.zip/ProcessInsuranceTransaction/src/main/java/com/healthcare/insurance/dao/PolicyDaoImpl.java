package com.healthcare.insurance.dao;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.healthcare.insurance.model.Policy;
@Transactional
@Repository("policyDao")
public class PolicyDaoImpl implements PolicyDao {
    @Autowired
    private SessionFactory sessionFactory;
    protected Session getSession(){
        return sessionFactory.openSession();
    }
    /*
    @Autowired
    Policy policy;
    */
	public Policy getPolicyByPolicyId(long policyId, long policyHolderId) {
		// TODO Auto-generated method stub
		String sql = "from Policy where POLICY_ID = :id and POLICY_HOLDER_ID = :polHolder";
				
		Query query = getSession().createQuery(sql);
		query.setLong("id", policyId);
		query.setLong("polHolder", policyHolderId);
		Policy policy = (Policy) query.uniqueResult();
		return policy;		
	}
	@Override
	public int updatePolicyWithAccumulationForYear(long policyId, long policyHolderId, 
			                                        Double individualAccumulated, Double familyAccumulated) {
		// TODO Auto-generated method stub
		String updatePolicySql = "update Policy set INDIVIDUAL_ACCUMULATED = :individualAccumulation,"
				+ " FAMILY_ACCUMULATED = :familyAccumulation where POLICY_ID = :id and POLICY_HOLDER_ID = :polHolder";
		Query query = getSession().createQuery(updatePolicySql);
		query.setDouble("individualAccumulation", individualAccumulated);
		query.setDouble("familyAccumulation", familyAccumulated);
		query.setLong("id", policyId);
		query.setLong("polHolder", policyHolderId);
		int rowCount = query.executeUpdate();
		return rowCount;
	}

}
