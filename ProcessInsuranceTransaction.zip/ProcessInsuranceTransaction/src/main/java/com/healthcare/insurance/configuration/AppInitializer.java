package com.healthcare.insurance.configuration;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRegistration;


import org.springframework.context.annotation.ComponentScan;
import org.springframework.web.WebApplicationInitializer;
import org.springframework.web.context.ContextLoaderListener;
import org.springframework.web.context.support.AnnotationConfigWebApplicationContext;
import org.springframework.web.servlet.DispatcherServlet;

@ComponentScan(basePackages = "com.healthcare.insurance")
public class AppInitializer implements WebApplicationInitializer {
 
    public void onStartup(ServletContext container) throws ServletException {

        AnnotationConfigWebApplicationContext ctx = new AnnotationConfigWebApplicationContext();
        container.setInitParameter("contextConfigLocation", "<NONE>"); 
        ctx.register(AppConfig.class);
        //ctx.register(TransactionsBatchConfiguration.class);
        ctx.setConfigLocation("com.healthcare.insurance.configuration");
        container.addListener(new ContextLoaderListener(ctx));
        ctx.setServletContext(container);

        ServletRegistration.Dynamic servlet = container.addServlet(
                "dispatcher", new DispatcherServlet(ctx));

        servlet.setLoadOnStartup(1);
        servlet.setAsyncSupported(true);
        servlet.addMapping("/");

        ServletRegistration.Dynamic newservlet = container.addServlet(
                "dispatcher2", new DispatcherServlet(ctx));

        newservlet.setLoadOnStartup(2);
        newservlet.setAsyncSupported(true);
        newservlet.addMapping("/rest/*");
        
        /*
        ctx.setConfigLocation("com.healthcare.insurance.configuration");
        ServletRegistration.Dynamic jerseyServlet = container.addServlet(
                "dispatcher2", new ServletContainer());
        jerseyServlet.setInitParameter("javax.ws.rs.Application", 
        		"com.healthcare.insurance.service.MyRestApplication");
        jerseyServlet.setLoadOnStartup(2);
        jerseyServlet.setAsyncSupported(true);
        jerseyServlet.addMapping("/rest/*");
       */
    }
 
}
