package com.healthcare.insurance.service;

import java.util.Map;

import javax.servlet.ServletContext;

import org.joda.time.LocalDate;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.omg.IOP.ServiceContext;

//import javax.ws.rs.Path;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionException;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.web.context.support.AnnotationConfigWebApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.ComponentScan.Filter;
import org.springframework.context.annotation.FilterType;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.stereotype.Service;

import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.context.ContextLoaderListener;
import org.springframework.web.context.WebApplicationContext;

import com.healthcare.insurance.configuration.AppConfig;
import com.healthcare.insurance.configuration.TransactionsBatchConfiguration;
import com.healthcare.insurance.dao.TransactionsProcessedDao;
import com.healthcare.insurance.model.TransactionFile;
import com.healthcare.insurance.model.TransactionsProcessed;
import com.healthcare.insurance.service.ProcessTransactionService;

@ComponentScan(basePackages = "com.healthcare.insurance")
@Service("processTransactionService")
@Transactional
//@Path("/rest")
public class ProcessTransactionServiceImpl implements ProcessTransactionService {

	//@Path("/rest")
	//public void processTransaction() {
    @Autowired
    TransactionsItemProcessor transactionsItemProcessor;
    //= new TransactionsItemProcessor();
	@Autowired
	TransactionsProcessedDao transactionsProcessedDao;
	
	public TransactionsProcessed processRealtimeTransaction(Map<String, String> realTimeTransactionMap) {
		// TODO Auto-generated method stub
		// TODO Auto-generated method stub
		/* 
		 * Call Spring batch service if possible for each entry in input
		 * transaction file.
		 */
		
		TransactionsProcessed tp = new TransactionsProcessed();
		tp.setPolicyId(Long.valueOf(realTimeTransactionMap.get("policyId")));
		tp.setPolicyHolderId(Long.valueOf(realTimeTransactionMap.get("policyHolderId")));
		DateTimeFormatter formatter = DateTimeFormat.forPattern("mm/dd/yyyy");
		String date = realTimeTransactionMap.get("dateOfServiceId");
		date = date.replaceAll("%2F", "/");
		LocalDate localDate = LocalDate.parse(date, formatter);
		tp.setDateOfService(localDate);	
		String mainCat = realTimeTransactionMap.get("mainCategoryId").replaceAll("\\+", " ");
		tp.setMainCategory(mainCat);
		String subCat = realTimeTransactionMap.get("subCategoryId").replaceAll("\\+", " ");
		tp.setSubCategory(subCat);
		tp.setBilledAmount(Double.valueOf(realTimeTransactionMap.get("billedAmountId")));
		try {
			tp = transactionsItemProcessor.process(tp);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		transactionsProcessedDao.insert(tp);
		return tp;
		/*
		ApplicationContext context = new 
				AnnotationConfigApplicationContext(TransactionsBatchConfiguration.class);
		JobLauncher jobLauncher = (JobLauncher) context.getBean("jobLauncher");
		Job job = (Job) context.getBean("createTransactionsOutput");
        try {
            JobExecution execution = jobLauncher.run(job, new JobParameters());
            System.out.println("Job Exit Status : "+ execution.getStatus());
            //((AnnotationConfigApplicationContext) context).close();
      
        } catch (JobExecutionException e) {
            System.out.println("Job ExamResult failed");
            e.printStackTrace();
        }
        */
	}

}
