package com.healthcare.insurance.configuration;

import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import com.healthcare.insurance.service.ProcessTransactionService;
import com.healthcare.insurance.service.ProcessTransactionServiceImpl;


@Configuration
@EnableBatchProcessing
@EnableTransactionManagement
@ComponentScan({ "com.healthcare.insurance" })
@PropertySource(value = { "classpath:application.properties" })
public class TransactionsBatchConfiguration {
	
	@Bean
    public ProcessTransactionService processTransactionService() {
    	return new ProcessTransactionServiceImpl();
    }
 } 
