package com.healthcare.insurance.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;
import com.healthcare.insurance.model.TransactionsProcessed;
import com.healthcare.insurance.service.ProcessTransactionService;

@RestController
@Controller
@RequestMapping("/Service")
@EnableTransactionManagement
public class AppController2 {
    @Autowired
    ProcessTransactionService processTransactionService;
    @RequestMapping(value = "/")
    public String newEmployee(@RequestBody String name) {
        Gson gson = new Gson();
    	Map<String, String> mp = new HashMap<String, String>();
    	String [] nameValuePairs = name.split("&");
    	for (String nameValuePair:nameValuePairs) {
    		String[] nameValue = nameValuePair.split("=");
    		mp.put(nameValue[0], nameValue[1]);
    	}
        TransactionsProcessed tp = processTransactionService.processRealtimeTransaction(mp);
        return gson.toJson(tp);
    }
}
