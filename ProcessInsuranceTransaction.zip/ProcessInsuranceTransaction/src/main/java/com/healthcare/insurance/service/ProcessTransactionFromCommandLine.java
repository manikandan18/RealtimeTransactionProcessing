package com.healthcare.insurance.service;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.JobParametersInvalidException;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.batch.core.repository.JobRestartException;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.healthcare.insurance.configuration.TransactionsBatchConfigurationCommandLine;

@Component
//@ComponentScan(basePackages = "com.healthcare.insurance.service")
@Service("processTransactionFromCommandLine")
@Transactional
public class ProcessTransactionFromCommandLine {

    public static void main(String[] args) {
    	@SuppressWarnings("resource")
		AnnotationConfigApplicationContext annConfig = new AnnotationConfigApplicationContext(TransactionsBatchConfigurationCommandLine.class);
    	JobLauncher jobLauncher = (JobLauncher) annConfig.getBean("jobLauncher");
    	Job job = (Job) annConfig.getBean("createTransactionsOutput");
    	JobParametersBuilder jobParametersBuilder = new JobParametersBuilder();
    	jobParametersBuilder.addString("inputFileName", args[0]);
    	jobParametersBuilder.addString("outputFileName", args[1]);
    	try {
            jobLauncher.run(job, jobParametersBuilder.toJobParameters());
		} catch (JobExecutionAlreadyRunningException | JobRestartException | JobInstanceAlreadyCompleteException
				| JobParametersInvalidException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
}
