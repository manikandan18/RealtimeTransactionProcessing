package com.healthcare.insurance.dao;

import org.springframework.transaction.annotation.Transactional;

import com.healthcare.insurance.model.PlanDescriptions;
@Transactional
public interface PlanDescriptionsDao {
	PlanDescriptions getPlanDescriptionsForPlanId(String planId);
}
