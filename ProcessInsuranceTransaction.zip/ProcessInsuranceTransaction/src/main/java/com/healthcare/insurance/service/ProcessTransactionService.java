package com.healthcare.insurance.service;

import java.util.Map;

import org.springframework.transaction.annotation.Transactional;

import com.healthcare.insurance.model.TransactionFile;
import com.healthcare.insurance.model.TransactionsProcessed;
@Transactional
public interface ProcessTransactionService {
    TransactionsProcessed processRealtimeTransaction(Map<String, String> realTimeTransactionMap);
}
