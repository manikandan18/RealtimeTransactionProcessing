package com.healthcare.insurance.configuration;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.sql.DataSource;

import org.hibernate.SessionFactory;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.launch.support.SimpleJobLauncher;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemStreamWriter;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.database.HibernateItemWriter;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.FlatFileItemWriter;
import org.springframework.batch.item.file.mapping.DefaultLineMapper;
import org.springframework.batch.item.file.transform.BeanWrapperFieldExtractor;
import org.springframework.batch.item.file.transform.DelimitedLineAggregator;
import org.springframework.batch.item.file.transform.DelimitedLineTokenizer;
import org.springframework.batch.item.support.CompositeItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.EnvironmentAware;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.Scope;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.core.env.Environment;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.task.SimpleAsyncTaskExecutor;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.hibernate4.HibernateTransactionManager;
import org.springframework.orm.hibernate4.LocalSessionFactoryBuilder;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.batch.core.repository.support.MapJobRepositoryFactoryBean;
import org.springframework.batch.core.scope.StepScope;

import com.healthcare.insurance.dao.PlanCoverageDao;
import com.healthcare.insurance.dao.PlanCoverageDaoImpl;
import com.healthcare.insurance.dao.PlanDescriptionsDao;
import com.healthcare.insurance.dao.PlanDescriptionsDaoImpl;
import com.healthcare.insurance.dao.PolicyDao;
import com.healthcare.insurance.dao.PolicyDaoImpl;
import com.healthcare.insurance.dao.TransactionsProcessedDao;
import com.healthcare.insurance.dao.TransactionsProcessedDaoImpl;
import com.healthcare.insurance.model.TransactionFile;
import com.healthcare.insurance.model.TransactionsProcessed;
import com.healthcare.insurance.service.TransactionsFieldSetMapper;
import com.healthcare.insurance.service.TransactionsItemProcessor;
/* 
 * This configuration file is created to avoid defaultServletMapping exception that might appear if run
 * from command line
 */

@Configuration
@EnableBatchProcessing
@EnableTransactionManagement
//@Import(HibernateConfiguration.class)
//@ComponentScan({ "com.healthcare.insurance" })
@PropertySource(value = { "classpath:application.properties" })
public class TransactionsBatchConfigurationCommandLine implements EnvironmentAware {

   /* 
    @Autowired
    private HibernateConfiguration hibernateConfiguration;
   */
    
    //@Resource
    private Environment environment;
  
    @Autowired
     TransactionFile transactionFile;

	@Value("${jdbc.driverClassName}")
    private String driverClassName;
    @Value("${jdbc.url}")
    private String url;  
    @Value("${jdbc.username}")
    private String username;     
    @Value("${jdbc.password}")
    private String password;  
    @Value("${hibernate.dialect}")
    private String dialect; 
    @Value("${hibernate.show_sql}")
    private boolean show_sql; 
    @Value("${hibernate.format_sql}")
    private boolean format_sql;
    
    /*
    @Autowired
    private SessionFactory sessionFactory;

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
        
    }

    public SessionFactory getSessionFactory() {
        return sessionFactory;
    }
    */
    @SuppressWarnings("deprecation")
	/*
    public Session getCurrentSession() {
    	return sessionFactory.openSession();
    }
    */
    /*
    @Autowired
    private LocalSessionFactoryBean session;
    */
    @Bean
    @Transactional
    public JobRepository jobRepository() throws Exception {

        return new MapJobRepositoryFactoryBean(transactionManager()).getJobRepository();
    
    }
    @Autowired
    @Bean(name = "sessionFactory")
    public SessionFactory getSessionFactory(DataSource dataSource) {
     
        LocalSessionFactoryBuilder sessionBuilder = new LocalSessionFactoryBuilder(dataSource);
     
        sessionBuilder.addAnnotatedClasses(TransactionsProcessed.class);
        sessionBuilder.scanPackages("com.healthcare.insurance.model");
        sessionBuilder.addProperties(hibernateProperties());
        return sessionBuilder.buildSessionFactory();
    }

    @Bean
    public DataSource dataSource() {
        DriverManagerDataSource dataSource = new DriverManagerDataSource();
        hibernateProperties();
        dataSource.setDriverClassName(environment.getRequiredProperty("jdbc.driverClassName"));
        dataSource.setUrl(environment.getRequiredProperty("jdbc.url"));
        dataSource.setUsername(environment.getRequiredProperty("jdbc.username"));
        dataSource.setPassword(environment.getRequiredProperty("jdbc.password"));
        return dataSource;
    }
   
    private Properties hibernateProperties() {
        Properties properties = new Properties();
        properties.put("hibernate.dialect", environment.getRequiredProperty("hibernate.dialect"));
        properties.put("hibernate.show_sql", environment.getRequiredProperty("hibernate.show_sql"));
        properties.put("hibernate.format_sql", environment.getRequiredProperty("hibernate.format_sql"));
        return properties;        
    }
    @Bean
    public static PropertySourcesPlaceholderConfigurer propertyConfigInDev() {
      return new PropertySourcesPlaceholderConfigurer();
    }
    @Bean
    @Autowired
    public PlatformTransactionManager transactionManager() {
        /*
    	DataSourceTransactionManager dtm = new DataSourceTransactionManager();
        dtm.setDataSource(dataSource());
        return dtm;
        */
        //return new ResourcelessTransactionManager();
      
        HibernateTransactionManager htm = new HibernateTransactionManager();
        htm.setSessionFactory(getSessionFactory(dataSource()));
        return htm;
        
    }

    @Bean
    public JobLauncher jobLauncher() throws Exception {
        SimpleJobLauncher jobLauncher = new SimpleJobLauncher();
        jobLauncher.setJobRepository(jobRepository());
        jobLauncher.setTaskExecutor(new SimpleAsyncTaskExecutor());
        return jobLauncher;
    }
    
    @Bean
    public TransactionFile transactionFile() {
    	return new TransactionFile();
    }
    @Bean
    @Scope("step")
    public FlatFileItemReader<TransactionsProcessed> reader(@Value("#{jobParameters['inputFileName']}") String inputFileName) {
        FlatFileItemReader<TransactionsProcessed> reader = new FlatFileItemReader<TransactionsProcessed>();
        System.out.println("Mani value of input transaction file is "+inputFileName);
        //System.out.println("Mani value of input transaction file 2 is "+transactionFile.getOutput_name());
        reader.setResource(new FileSystemResource(new File(inputFileName)));
        reader.setLineMapper(new DefaultLineMapper<TransactionsProcessed>() {{
            setLineTokenizer(new DelimitedLineTokenizer() {{
                setNames(new String[] {"policyId", "policyHolderId", "dateOfService",
                		"mainCategory", "subCategory", "billedAmount"});
            }});
            setFieldSetMapper(new TransactionsFieldSetMapper() {{
                setTargetType(TransactionsProcessed.class);
            }

			private void setTargetType(Class<TransactionsProcessed> class1) {
				// TODO Auto-generated method stub
				
			}});
        }});
        return reader;
    }
    @Bean
    public StepScope stepScope() {
    	return new StepScope();
    }
    @Bean
    @Scope(value = "step")
    public ItemStreamWriter<TransactionsProcessed> fileWriter(@Value("#{jobParameters['outputFileName']}") String outputFileName) {
     	FlatFileItemWriter<TransactionsProcessed> writer = new FlatFileItemWriter<TransactionsProcessed>();
    	DelimitedLineAggregator<TransactionsProcessed> delLineAgg = new DelimitedLineAggregator<TransactionsProcessed>();
    	delLineAgg.setDelimiter(",");
    	System.out.println("Mani value of output transaction file is "+outputFileName);
    	BeanWrapperFieldExtractor<TransactionsProcessed> fieldExtractor = new BeanWrapperFieldExtractor<TransactionsProcessed>();
    	fieldExtractor.setNames(new String[] {"policyId", "policyHolderId", "dateOfService",
    			"mainCategory", "subCategory", "billedAmount", "policyHolderPaysUSD",
    			"planPaysUSD", "coverageDescription", "individualAccumulated",
    			"familyAccumulated", "errorCode", "errorMessage", "processingMessage"});
    	delLineAgg.setFieldExtractor(fieldExtractor);
    	writer.setLineAggregator(delLineAgg);
    	//writer.setResource(new FileSystemResource("src/main/resources/OutputTransactions.csv"));
    	writer.setResource(new FileSystemResource(new File(outputFileName)));
    	//writer.setResource(new FileSystemResource(outputFileName));
    	return writer;
    }
    @Bean
    public ItemWriter<TransactionsProcessed> dbWriter() {
     	HibernateItemWriter<TransactionsProcessed> writer = new HibernateItemWriter<TransactionsProcessed>();
     	if (getSessionFactory(dataSource()) == null)
     		System.out.println("Mani session factory is null");
     	/*
     	if (sessionFactory.getCurrentSession() == null)
     		sessionFactory.openSession();
     	*/	
     	writer.setSessionFactory(getSessionFactory(dataSource()));
     	//List<? extends TransactionsProcessed> lst = new ArrayList();
     	//writer.write(lst);
         return writer;
    }
    @Bean
    public ItemWriter<TransactionsProcessed> writer() {
     	CompositeItemWriter<TransactionsProcessed> writer = new CompositeItemWriter<TransactionsProcessed>();
     	List<ItemWriter<? super TransactionsProcessed>> delegates = new ArrayList<ItemWriter<? super TransactionsProcessed>>();
     	delegates.add(fileWriter(null));
     	delegates.add(dbWriter());
     	writer.setDelegates(delegates);
     	//writer.setIgnoreItemStream(true);
        return writer;
    }
    
    @Bean
    public ItemProcessor<TransactionsProcessed, TransactionsProcessed> processor() {
        return new TransactionsItemProcessor();
    }
    
    @Bean
    @Transactional
    public Job createTransactionsOutput(JobBuilderFactory jobs, Step step) {
    	System.out.println("Mani this bean is also injected already");
        return jobs.get("createTransactionsOutput")
                .flow(step)
                .end()
                .build();
    }

    @Bean
    public Step step(StepBuilderFactory stepBuilderFactory, ItemReader<TransactionsProcessed> reader,
            ItemWriter<TransactionsProcessed> writer, ItemProcessor<TransactionsProcessed, TransactionsProcessed> processor) {
        System.out.println("Mani this bean is also injected already");
        
    	return stepBuilderFactory.get("step")
                .<TransactionsProcessed, TransactionsProcessed> chunk(5)
                .reader(reader)
                .processor(processor)
                .writer(writer)
                .build();
    }

    /*
    @Bean
    public Step step(StepBuilderFactory stepBuilderFactory, ItemReader<TransactionsProcessed> reader,
            ItemWriter<TransactionsProcessed> compositeWriter, 
            FlatFileItemWriter<TransactionsProcessed> fileWriter,
            ItemProcessor<TransactionsProcessed, TransactionsProcessed> processor) {

        
    	return stepBuilderFactory.get("step")
                .<TransactionsProcessed, TransactionsProcessed> chunk(5)
                .reader(reader)
                .processor(processor)
                .writer(compositeWriter)
                .stream(fileWriter)
                .build();
    } 
    */ 
    /*
    @Bean
    public ProcessTransactionService processTransactionService() {
    	return new ProcessTransactionServiceImpl();
    }
    */
    @Bean
    public PlanDescriptionsDao planDescriptionsDao() {
    	return new PlanDescriptionsDaoImpl();
    }
    @Bean
    public TransactionsProcessedDao transactionsProcessedDao() {
    	return new TransactionsProcessedDaoImpl();
    }
    @Bean
    public PolicyDao policyDao() {
    	return new PolicyDaoImpl();
    }
    @Bean
    public PlanCoverageDao planCoverageDao() {
    	return new PlanCoverageDaoImpl();
    }
    @Bean
    public TransactionsItemProcessor transactionsItemProcessor() {
    	return new TransactionsItemProcessor();
    }
	@Override
	public void setEnvironment(final Environment environment) {
		// TODO Auto-generated method stub
		this.environment = environment;
	}
} 
