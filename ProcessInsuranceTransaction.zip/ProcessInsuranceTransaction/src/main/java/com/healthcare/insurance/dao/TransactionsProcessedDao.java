package com.healthcare.insurance.dao;

import org.springframework.transaction.annotation.Transactional;

import com.healthcare.insurance.model.TransactionsProcessed;

public interface TransactionsProcessedDao {
   @Transactional	
   public void insert(TransactionsProcessed tp);
}
