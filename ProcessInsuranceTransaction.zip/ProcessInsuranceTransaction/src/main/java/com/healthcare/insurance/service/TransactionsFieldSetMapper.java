package com.healthcare.insurance.service;

import org.joda.time.format.DateTimeFormatter;

import org.joda.time.LocalDate;
import org.joda.time.format.DateTimeFormat;
import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.FieldSet;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.validation.BindException;

import com.healthcare.insurance.model.TransactionsProcessed;
@Transactional
public class TransactionsFieldSetMapper implements FieldSetMapper<TransactionsProcessed>{

	public TransactionsProcessed mapFieldSet(FieldSet fieldSet) throws BindException {
		// TODO Auto-generated method stub
		TransactionsProcessed tp = new TransactionsProcessed();
		tp.setPolicyId(fieldSet.readLong(0));
		tp.setPolicyHolderId(fieldSet.readLong(1));
		DateTimeFormatter formatter = DateTimeFormat.forPattern("MM/d/yyyy");
		String date = fieldSet.readString(2);
		LocalDate localDate = LocalDate.parse(date, formatter);
		tp.setDateOfService(localDate);
		tp.setMainCategory(fieldSet.readString(3));
		tp.setSubCategory(fieldSet.readString(4));
		tp.setBilledAmount(fieldSet.readDouble(5));
		System.out.println("The mapper is also called already");
		return tp;
	}

}
