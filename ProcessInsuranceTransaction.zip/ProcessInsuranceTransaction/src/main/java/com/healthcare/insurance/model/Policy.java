package com.healthcare.insurance.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.Type;
import org.joda.time.LocalDate;
import org.springframework.stereotype.Component;
@Component
@Entity
@Table(name="POLICY")
public class Policy implements Serializable{
	private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}

	public long getPolicyId() {
		return policyId;
	}
	public void setPolicyId(long policyId) {
		this.policyId = policyId;
	}
	public long getPolicyHolderId() {
		return policyHolderId;
	}
	public void setPolicyHolderId(long policyHolderId) {
		this.policyHolderId = policyHolderId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getPlanId() {
		return planId;
	}
	public void setPlanId(String planId) {
		this.planId = planId;
	}
	public LocalDate getCoverageStartDate() {
		return coverageStartDate;
	}
	public void setCoverageStartDate(LocalDate coverageStartDate) {
		this.coverageStartDate = coverageStartDate;
	}
	public LocalDate getCoverageEndDate() {
		return coverageEndDate;
	}
	public void setCoverageEndDate(LocalDate coverageEndDate) {
		this.coverageEndDate = coverageEndDate;
	}
	public double getIndividualAccumulated() {
		return individualAccumulated;
	}
	public void setIndividualAccumulated(double individualAccumulated) {
		this.individualAccumulated = individualAccumulated;
	}
	public double getFamilyAccumulated() {
		return familyAccumulated;
	}
	public void setFamilyAccumulated(double familyAccumulated) {
		this.familyAccumulated = familyAccumulated;
	}
	@Column(name = "POLICY_ID", nullable = false)
    private long policyId;
	@Column(name = "POLICY_HOLDER_ID", nullable = false)
    private long policyHolderId;
	@Column(name = "FIRST_NAME", nullable = false)
    private String firstName;
	@Column(name = "LAST_NAME", nullable = false)
    private String lastName;
	@Column(name = "PLAN_ID", nullable = false)
    private String planId;
	   @Temporal(TemporalType.DATE)
	   @Type(type = "org.jadira.usertype.dateandtime.joda.PersistentLocalDate")
	@Column(name = "COVERAGE_START_DATE", nullable = false)
    private LocalDate coverageStartDate;
	   @Temporal(TemporalType.DATE)
	   @Type(type = "org.jadira.usertype.dateandtime.joda.PersistentLocalDate")	   
	@Column(name = "COVERAGE_END_DATE", nullable = true)
    private LocalDate coverageEndDate;	
	@Column(name = "INDIVIDUAL_ACCUMULATED", nullable = false)
    private double individualAccumulated;	
	@Column(name = "FAMILY_ACCUMULATED", nullable = false)
    private double familyAccumulated;	
}
