package com.healthcare.insurance.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.stereotype.Component;
@Component
@Entity
@Table(name="PLAN_DESCRIPTIONS")
public class PlanDescriptions {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    
    public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getPlanId() {
		return planId;
	}
	public void setPlanId(String planId) {
		this.planId = planId;
	}
	public String getPlanName() {
		return planName;
	}
	public void setPlanName(String planName) {
		this.planName = planName;
	}
	public String getCoverageType() {
		return coverageType;
	}
	public void setCoverageType(String coverageType) {
		this.coverageType = coverageType;
	}
	public double getEstimatedPremium() {
		return estimatedPremium;
	}
	public void setEstimatedPremium(double estimatedPremium) {
		this.estimatedPremium = estimatedPremium;
	}

	@Column(name = "PLAN_ID", nullable = false)
    private String planId;
    @Column(name = "PLAN_NAME", nullable = false)
    private String planName;
    @Column(name = "COVERAGE_TYPE", nullable = false)
    private String coverageType;
    @Column(name = "ESTIMATED_PREMIUM", nullable = false)
    private double estimatedPremium;
    public double getAnnualDeductibleIndividual() {
		return annualDeductibleIndividual;
	}
	public void setAnnualDeductibleIndividual(double annualDeductibleIndividual) {
		this.annualDeductibleIndividual = annualDeductibleIndividual;
	}
	public double getAnnualDeductibleFamily() {
		return annualDeductibleFamily;
	}
	public void setAnnualDeductibleFamily(double annualDeductibleFamily) {
		this.annualDeductibleFamily = annualDeductibleFamily;
	}

	@Column(name = "ANNUAL_DEDUCTIBLE_INDIVIDUAL", nullable = false)
    private double annualDeductibleIndividual;
    @Column(name = "ANNUAL_DEDUCTIBLE_FAMILY", nullable = false)
    private double annualDeductibleFamily;
}
