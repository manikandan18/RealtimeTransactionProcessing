package com.healthcare.insurance.dao;

import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.transaction.annotation.Transactional;

import com.healthcare.insurance.model.Policy;
@Transactional
@Configurable
public interface PolicyDao {
    public Policy getPolicyByPolicyId(long policyId, long policyHolderId);
    public int updatePolicyWithAccumulationForYear(long policyId, long policyHolderId, 
    		Double individualAccumulated, Double familyAccumulated);
}
