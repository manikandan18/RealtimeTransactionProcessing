package com.healthcare.insurance.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.channels.FileChannel;

import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.JobParametersInvalidException;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.batch.core.repository.JobRestartException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.healthcare.insurance.configuration.TransactionsBatchConfigurationCommandLine;
//import com.healthcare.insurance.configuration.TransactionsBatchConfiguration;
import com.healthcare.insurance.model.TransactionFile;
import com.healthcare.insurance.service.ProcessTransactionService;
@Controller
@RequestMapping("/")
@EnableTransactionManagement
@SessionAttributes("transactionFile")
public class AppController {

    @Autowired
    ProcessTransactionService processTransactionService;
    /*
    @Autowired
    TransactionsBatchConfiguration transactionsBatchConfiguration;
    */

    @Autowired
    MessageSource messageSource;

    /*
     * This method will provide the medium to add a new transaction.
     */
    @Autowired
    TransactionFile transactionFile;
    @RequestMapping(value = { "/new" }, method = RequestMethod.GET)
    public ModelAndView newEmployee(ModelMap model) {
    	//TransactionFile transactionFile = new TransactionFile();
        model.addAttribute("transactionFile", transactionFile);
        //model.addAttribute("edit", false);
        System.out.println("Mani entered here");
        return new ModelAndView("processtransaction");
    }
    @RequestMapping(value = { "rest" }, method = RequestMethod.GET)
    public ModelAndView newEmployees(ModelMap model) {
    	//TransactionFile transactionFile = new TransactionFile();
        model.addAttribute("transactionFile", transactionFile);
        //model.addAttribute("edit", false);
        return new ModelAndView("processrealtimetransaction");
    }
    @Autowired
    JobLauncher jobLauncher;

    @Autowired
    Job job;
    /*
     * This method will provide the medium to process transaction just got added.
     */    
    @RequestMapping(value = { "/new" }, method = RequestMethod.POST)
    public String processTransaction(TransactionFile transactionFile,
    		BindingResult result, ModelMap model) {

        //model.addAttribute("transactionFile", transactionFile);

        if (result.hasErrors()) {
            return "processtransaction";
        }
   
        try {
        	JobParametersBuilder jobParametersBuilder = new JobParametersBuilder();
        	jobParametersBuilder.addString("inputFileName", transactionFile.getInput_name());
        	jobParametersBuilder.addString("outputFileName", transactionFile.getOutput_name());
        	
			JobExecution jobExecution = jobLauncher.run(job, jobParametersBuilder.toJobParameters());
			System.out.println("The job status is "+jobExecution.getStatus());
			/*
			//if (jobExecution.getStatus().equals("COMPLETED")) {
			File source = new File("C:\\Users\\Mani\\workspace\\ProcessInsuranceTransaction\\src\\main\\resources\\OutputTransactions.csv");
            File dest = new File(transactionFile.getOutput_name());
            FileChannel inputChannel = null;
            FileChannel outputChannel = null;
			FileInputStream fileInputStream = new FileInputStream(source);
			inputChannel = fileInputStream.getChannel();
			FileOutputStream fileOutputStream = new FileOutputStream(dest);
			outputChannel = fileOutputStream.getChannel();
			outputChannel.transferFrom(inputChannel, 0, inputChannel.size());
			System.out.println(source.toPath());
			inputChannel.close();
			outputChannel.close();
			fileInputStream.close();
			fileOutputStream.close();
					//Files.deleteIfExists(source.toPath());
			//} 
			 * 
			 */
		} catch (JobExecutionAlreadyRunningException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JobRestartException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JobInstanceAlreadyCompleteException e) {
			model.addAttribute("error", "Input file " + transactionFile.getInput_name() + " already processed. "
					+ "If you want to run this job again, change the parameters.");
				return "error";
		} catch (JobParametersInvalidException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        /*
        catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
           //processTransactionService.processTransaction(transactionFile);
        */
        model.addAttribute("success", "Input file " + transactionFile.getInput_name() + " processed successfully");
        return "success";
    }
}
