package com.healthcare.insurance.dao;

import org.springframework.transaction.annotation.Transactional;

import com.healthcare.insurance.model.PlanCoverage;
@Transactional
public interface PlanCoverageDao {
   public PlanCoverage getPlanCoverage(long policyId, long policyHolderId, 
		   String planId, String mainCatefory, String subCategory);
}
