package com.healthcare.insurance.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.healthcare.insurance.model.TransactionsProcessed;

@Repository("transactionsProcessedDao")
public class TransactionsProcessedDaoImpl implements TransactionsProcessedDao {
    @Autowired
    private SessionFactory sessionFactory;
    protected Session getSession(){
        return sessionFactory.openSession();
    }
	public void insert(TransactionsProcessed tp) {
		// TODO Auto-generated method stub
		  System.out.println(tp.getBilledAmount());
		  System.out.println(tp.getCoverageDescription());
		  System.out.println(tp.getPlanPaysUSD());
		  System.out.println(tp.getPolicyHolderPaysUSD());
		  System.out.println(tp.getIndividualAccumulated());
		  System.out.println(tp.getFamilyAccumulated());
			Transaction tx = getSession().beginTransaction();
			getSession().save(tp);
			getSession().flush();
			tx.commit();
			getSession().close();
		 
	}

}
