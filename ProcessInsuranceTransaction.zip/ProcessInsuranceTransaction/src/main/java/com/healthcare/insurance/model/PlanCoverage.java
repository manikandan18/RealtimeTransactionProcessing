package com.healthcare.insurance.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.stereotype.Component;
@Component
@Entity
@Table(name="PLAN_COVERAGE")
public class PlanCoverage {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getMainCategory() {
		return mainCategory;
	}
	public void setMainCategory(String mainCategory) {
		this.mainCategory = mainCategory;
	}
	public String getSubCategory() {
		return subCategory;
	}
	public void setSubCategory(String subCategory) {
		this.subCategory = subCategory;
	}
	public String getPlanId() {
		return planId;
	}
	public void setPlanId(String planId) {
		this.planId = planId;
	}
	public String getCoverageDescription() {
		return coverageDescription;
	}
	public void setCoverageDescription(String coverageDescription) {
		this.coverageDescription = coverageDescription;
	}
	public double getCoverageAmount() {
		return coverageAmount;
	}
	public void setCoverageAmount(double coverageAmount) {
		this.coverageAmount = coverageAmount;
	}
	public String getIsPercentage() {
		return isPercentage;
	}
	public void setIsPercentage(String isPercentage) {
		this.isPercentage = isPercentage;
	}
	@Column(name = "MAIN_CATEGORY", nullable = false)
    private String mainCategory;
	@Column(name = "SUB_CATEGORY", nullable = false)
    private String subCategory;
	@Column(name = "PLAN_ID", nullable = false)
    private String planId;
	@Column(name = "COVERAGE_DESCRIPTION", nullable = false)
    private String coverageDescription;	
	@Column(name = "COVERAGE_AMOUNT", nullable = false)
    private double coverageAmount;
	@Column(name = "IS_PERCENTAGE", nullable = false)
    private String isPercentage;
}
