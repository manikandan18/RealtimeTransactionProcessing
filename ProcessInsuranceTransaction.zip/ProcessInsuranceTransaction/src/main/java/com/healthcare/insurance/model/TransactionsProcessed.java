package com.healthcare.insurance.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Type;
import org.joda.time.LocalDate;
import org.springframework.stereotype.Component;
@Component
@Entity
@Table(name = "Transactions_Processed")

public class TransactionsProcessed {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	@Column(name = "POLICY_ID", nullable = false)
	private long policyId;
	public long getPolicyId() {
		return policyId;
	}

	public void setPolicyId(long policyId) {
		this.policyId = policyId;
	}

	public long getPolicyHolderId() {
		return policyHolderId;
	}

	public void setPolicyHolderId(long policyHolderId) {
		this.policyHolderId = policyHolderId;
	}

	public LocalDate getDateOfService() {
		return dateOfService;
	}

	public void setDateOfService(LocalDate dateOfService) {
		this.dateOfService = dateOfService;
	}

	public String getMainCategory() {
		return mainCategory;
	}

	public void setMainCategory(String mainCategory) {
		this.mainCategory = mainCategory;
	}

	public String getSubCategory() {
		return subCategory;
	}

	public void setSubCategory(String subCategory) {
		this.subCategory = subCategory;
	}

	public double getBilledAmount() {
		return billedAmount;
	}

	public void setBilledAmount(double billedAmount) {
		this.billedAmount = billedAmount;
	}

	public double getPolicyHolderPaysUSD() {
		return policyHolderPaysUSD;
	}

	public void setPolicyHolderPaysUSD(double policyHolderPaysUSD) {
		this.policyHolderPaysUSD = policyHolderPaysUSD;
	}

	public double getPlanPaysUSD() {
		return planPaysUSD;
	}

	public void setPlanPaysUSD(double planPaysUSD) {
		this.planPaysUSD = planPaysUSD;
	}

	public String getCoverageDescription() {
		return coverageDescription;
	}

	public void setCoverageDescription(String coverageDescription) {
		this.coverageDescription = coverageDescription;
	}

	public double getIndividualAccumulated() {
		return individualAccumulated;
	}

	public void setIndividualAccumulated(double individualAccumulated) {
		this.individualAccumulated = individualAccumulated;
	}

	public double getFamilyAccumulated() {
		return familyAccumulated;
	}

	public void setFamilyAccumulated(double familyAccumulated) {
		this.familyAccumulated = familyAccumulated;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public String getProcessingMessage() {
		return processingMessage;
	}

	public void setProcessingMessage(String processingMessage) {
		this.processingMessage = processingMessage;
	}

	@Column(name = "POLICY_HOLDER_ID", nullable = false)
	private long policyHolderId;
	@Column(name = "DATE_OF_SERVICE", nullable = false)
	@Type(type="org.jadira.usertype.dateandtime.joda.PersistentLocalDate")
	private LocalDate dateOfService;
	@Column(name = "MAIN_CATEGORY", nullable = false)
	private String mainCategory;
	@Column(name = "SUB_CATEGORY", nullable = false)
	private String subCategory;	
	@Column(name = "BILLED_AMOUNT_USD", nullable = false)
	private double billedAmount;
	@Column(name = "POLICY_HOLDER_PAYS_USD", nullable = true)
	private double policyHolderPaysUSD;	
	@Column(name = "PLAN_PAYS_USD", nullable = true)
	private double planPaysUSD;	
	@Column(name = "COVERAGE_DESCRIPTION", nullable = true)
	private String coverageDescription;
	@Column(name = "INDIVIDUAL_ACCUMULATED", nullable = true)
	private double individualAccumulated;	
	@Column(name = "FAMILY_ACCUMULATED", nullable = true)
	private double familyAccumulated;
	@Column(name = "ERROR_CODE", nullable = true)
	private String errorCode;	
	@Column(name = "ERROR_MESSAGE", nullable = true)
	private String errorMessage;	
	@Column(name = "PROCESSING_MESSAGE", nullable = true)
	private String processingMessage;	
 }
