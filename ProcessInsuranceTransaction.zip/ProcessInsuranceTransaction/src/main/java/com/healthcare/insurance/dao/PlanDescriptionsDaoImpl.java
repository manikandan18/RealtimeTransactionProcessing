package com.healthcare.insurance.dao;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate4.LocalSessionFactoryBean;
import org.springframework.stereotype.Repository;

import com.healthcare.insurance.model.PlanDescriptions;
@Repository("planDescriptionsDao")
public class PlanDescriptionsDaoImpl implements PlanDescriptionsDao {
    @Autowired
    private SessionFactory sessionFactory;
	protected Session getSession(){
        return sessionFactory.openSession();
    }
	public PlanDescriptions getPlanDescriptionsForPlanId(String planId) {
		// TODO Auto-generated method stub
		String sql = "from PlanDescriptions where PLAN_ID = :id";
		Query query = getSession().createQuery(sql);
		query.setString("id", planId);
		PlanDescriptions pd = (PlanDescriptions) query.uniqueResult();
		return pd;
	}

}
